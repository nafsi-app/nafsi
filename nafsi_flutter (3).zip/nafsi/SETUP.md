# nafsi: running the real app with Firebase

This folder has the parts of the project that are yours: lib/main.dart and
pubspec.yaml. Flutter makes the rest (android/, ios/, web/ ...) for you.

1. Make the Flutter project (only once):
       flutter create nafsi
   Then copy this folder's lib/main.dart and pubspec.yaml into it,
   replacing the ones Flutter made.

2. Install the packages:
       cd nafsi
       flutter pub get

3. Connect your Firebase project (this creates lib/firebase_options.dart):
       dart pub global activate flutterfire_cli
       flutterfire configure
   Pick your existing Firebase project and the platforms you want.

4. In the Firebase console, check that:
   - Authentication > Sign-in method > Email/Password is ON
   - Firestore Database is created

5. Run it:
       flutter run

iOS note: if pod install complains about the platform version, open
ios/Podfile and set:  platform :ios, '13.0'  (or higher).

## Apple Health (Health page)

The Health page reads Apple Watch data from Apple Health with the
"health" package. It only works on a real iPhone (not the simulator,
not DartPad).

1. In ios/Runner/Info.plist, inside <dict>, add:
       <key>NSHealthShareUsageDescription</key>
       <string>nafsi reads your heart rate, HRV, sleep, breathing, activity, workouts, weight and water to show stress and eating warning signs.</string>
       <key>NSHealthUpdateUsageDescription</key>
       <string>nafsi does not change your health data.</string>

2. Open ios/Runner.xcworkspace in Xcode, select Runner > Signing &
   Capabilities > + Capability > HealthKit.

3. In ios/Podfile set:  platform :ios, '14.0'

4. Run on your iPhone. The first time you open the Health page, iOS asks
   which data nafsi can read. Turn everything on.

If the code shows errors around Health / HealthDataType after
"flutter pub get", the package may have changed in a newer version.
Check the package page on pub.dev for the current way to call it.

## Location and Google Maps (booking)

The booking page uses the phone's real location (geolocator) to show
distances to clinics and to check the user is inside the UAE. After
booking, the clinic is shown on a Google Map (google_maps_flutter).

1. In ios/Runner/Info.plist, inside <dict>, add:
       <key>NSLocationWhenInUseUsageDescription</key>
       <string>nafsi uses your location to show the clinics closest to you.</string>

2. Get a free Google Maps API key:
   Google Cloud Console > APIs & Services > enable "Maps SDK for iOS"
   (and "Maps SDK for Android") > Credentials > Create API key.

3. iOS: open ios/Runner/AppDelegate.swift and add
       import GoogleMaps
   at the top, and inside application(...didFinishLaunchingWithOptions...)
   before GeneratedPluginRegistrant.register(with: self):
       GMSServices.provideAPIKey("YOUR_MAPS_API_KEY")

4. Android (if you also build for Android): in
   android/app/src/main/AndroidManifest.xml, inside <application>, add
       <meta-data android:name="com.google.android.geo.API_KEY"
                  android:value="YOUR_MAPS_API_KEY"/>
   and above <application> add
       <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>

Do not upload the Maps key or the Gemini key to a public GitHub repo.
